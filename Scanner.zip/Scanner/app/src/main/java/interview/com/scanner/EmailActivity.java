package interview.com.scanner;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class EmailActivity extends AppCompatActivity {

    EditText barcode,dates;
    Button save;
    String barcodes,datess ;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);
        barcode = findViewById(R.id.inSubject);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        String date = sdf.format(c.getTime());

        dates = findViewById(R.id.inBody);
        dates.setText(date);

        save = findViewById(R.id.btnSendEmail);
        if (getIntent().getStringExtra("email_address") != null) {
            barcode.setText("Barcode : " + getIntent().getStringExtra("email_address"));
        }
        barcodes = barcode.getText().toString();
        datess = dates.getText().toString();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dbhelper mydatabase = new Dbhelper(EmailActivity.this);
                boolean trt = mydatabase.insertdata(barcodes,datess);
                if (trt){
                    Toast.makeText(getApplicationContext(), "Data Inserted", Toast.LENGTH_SHORT).show();
                    barcode.setText("");
                    dates.setText("");
            }}
        });

    }
}
